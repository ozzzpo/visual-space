const express = require("express");
const axios = require("axios");
const cors = require("cors");
const app = express();
const dotenv = require("dotenv");

dotenv.config();

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.get("/images", async (req, res) => {
  try {
    const response = await axios.get(
      `${process.env.API_BASE_URL}?key=${process.env.API_TOKEN}&image-type=photo&category=buildings`,
      {
        headers: {
          "User-Agent": req.header("User-Agent"),
          Accept: "application/json",
        },
      }
    );
    res.json(response.data);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Ошибка сервера" });
  }
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`Сервер запущен на http://localhost:${PORT}`);
});
